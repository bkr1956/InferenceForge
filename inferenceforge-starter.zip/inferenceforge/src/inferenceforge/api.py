"""InferenceForge HTTP API and Prometheus instrumentation."""
import os
import time
from fastapi import Depends, FastAPI
from fastapi.responses import Response
from pydantic import BaseModel, Field
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from .engines import get_engine

app = FastAPI(title="InferenceForge", version="0.1.0")

REQUESTS = Counter(
    "inferenceforge_generation_requests_total",
    "Completed generation requests",
    ["backend"],
)
LATENCY = Histogram(
    "inferenceforge_generation_duration_seconds",
    "Generation endpoint wall-clock duration in seconds",
    ["backend"],
    buckets=(0.005, 0.02, 0.1, 0.5, 1, 2, 5, 10, 30, 60, 120),
)


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    max_new_tokens: int = Field(default=32, ge=1, le=128)


class GenerateResponse(BaseModel):
    text: str
    generated_tokens: int | None
    model: str
    backend: str
    duration_ms: float


@app.get("/health")
def health():
    return {
        "status": "ok",
        "backend_configured": os.getenv("INFERENCEFORGE_BACKEND", "demo"),
        "real_inference": os.getenv("INFERENCEFORGE_BACKEND", "demo") == "hf",
    }


@app.post("/v1/generate", response_model=GenerateResponse)
def generate(body: GenerateRequest, engine=Depends(get_engine)):
    started = time.perf_counter()
    result = engine.generate(body.prompt, body.max_new_tokens)
    elapsed = time.perf_counter() - started
    REQUESTS.labels(backend=result.backend).inc()
    LATENCY.labels(backend=result.backend).observe(elapsed)
    return GenerateResponse(
        text=result.text,
        generated_tokens=result.generated_tokens,
        model=result.model,
        backend=result.backend,
        duration_ms=round(elapsed * 1000, 3),
    )


@app.get("/metrics")
def metrics():
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
