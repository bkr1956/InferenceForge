"""Demo backend for CI and an optional real Hugging Face backend.

Never publish demo timings as LLM inference performance measurements.
"""
import os
import threading
from dataclasses import dataclass
from functools import lru_cache

DEFAULT_MODEL = "HuggingFaceTB/SmolLM2-135M-Instruct"


@dataclass(frozen=True)
class Generation:
    text: str
    generated_tokens: int | None
    model: str
    backend: str


class DemoEngine:
    """Deterministic mock for API testing; does NOT run an LLM."""
    def generate(self, prompt: str, max_new_tokens: int) -> Generation:
        return Generation(
            text=f"[DEMO ONLY] Received: {prompt[:80]}",
            generated_tokens=None,
            model="demo-not-a-model",
            backend="demo",
        )


class HuggingFaceEngine:
    """Simple single-process baseline, not an optimized or streaming server."""
    def __init__(self, model_id: str):
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:
            raise RuntimeError(
                'Missing model dependencies. Run: python -m pip install -e ".[model]"'
            ) from exc
        self.torch = torch
        self.model_id = model_id
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForCausalLM.from_pretrained(model_id).to(self.device)
        self.model.eval()
        # This baseline serializes calls for predictability; later phases study batching.
        self.lock = threading.Lock()

    def generate(self, prompt: str, max_new_tokens: int) -> Generation:
        with self.lock:
            encoded = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            with self.torch.inference_mode():
                output = self.model.generate(
                    **encoded,
                    do_sample=False,
                    max_new_tokens=max_new_tokens,
                    pad_token_id=self.tokenizer.eos_token_id,
                )
            input_len = int(encoded["input_ids"].shape[-1])
            generated_ids = output[0][input_len:]
            text = self.tokenizer.decode(generated_ids, skip_special_tokens=True)
            return Generation(
                text=text,
                generated_tokens=int(generated_ids.shape[0]),
                model=self.model_id,
                backend="huggingface",
            )


@lru_cache(maxsize=1)
def get_engine():
    backend = os.getenv("INFERENCEFORGE_BACKEND", "demo").lower()
    if backend == "demo":
        return DemoEngine()
    if backend == "hf":
        return HuggingFaceEngine(os.getenv("INFERENCEFORGE_MODEL", DEFAULT_MODEL))
    raise ValueError("INFERENCEFORGE_BACKEND must be 'demo' or 'hf'")
