"""Reproducible concurrent HTTP benchmark for InferenceForge.

Reports observed response times. The demo backend cannot establish LLM speed.
"""
import argparse
import asyncio
import json
import math
import platform
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx


def percentile(values: list[float], pct: float) -> float:
    """Nearest-rank percentile, useful even for a single sample."""
    if not values:
        raise ValueError("Cannot calculate a percentile from zero measurements")
    ordered = sorted(values)
    idx = max(0, math.ceil(pct / 100 * len(ordered)) - 1)
    return round(ordered[idx], 3)


async def run_benchmark(
    url: str,
    prompt: str,
    num_requests: int,
    concurrency: int,
    warmups: int,
    max_new_tokens: int,
):
    if num_requests < 1 or concurrency < 1 or warmups < 0:
        raise ValueError("num_requests and concurrency must be positive; warmups >= 0")
    endpoint = url.rstrip("/") + "/v1/generate"
    body = {"prompt": prompt, "max_new_tokens": max_new_tokens}
    async with httpx.AsyncClient(timeout=180.0) as client:
        for _ in range(warmups):
            response = await client.post(endpoint, json=body)
            response.raise_for_status()
        sem = asyncio.Semaphore(concurrency)

        async def request_once():
            async with sem:
                started = time.perf_counter()
                response = await client.post(endpoint, json=body)
                response.raise_for_status()
                elapsed = (time.perf_counter() - started) * 1000
                return elapsed, response.json()

        started_batch = time.perf_counter()
        results = await asyncio.gather(*(request_once() for _ in range(num_requests)))
        wall_seconds = time.perf_counter() - started_batch

    latencies = [v[0] for v in results]
    payloads = [v[1] for v in results]
    backends = {p["backend"] for p in payloads}
    if len(backends) != 1:
        raise RuntimeError(f"Multiple backends in one benchmark: {backends}")
    backend = backends.pop()
    is_real = backend != "demo" and all(
        isinstance(p["generated_tokens"], int) for p in payloads
    )
    tokens = sum(p["generated_tokens"] for p in payloads) if is_real else None

    return {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "configuration": {
            "url": url,
            "prompt": prompt,
            "num_requests": num_requests,
            "concurrency": concurrency,
            "warmups": warmups,
            "max_new_tokens": max_new_tokens,
        },
        "environment": {"os": platform.platform(), "python": platform.python_version()},
        "backend": backend,
        "model": payloads[0]["model"],
        "is_real_llm_benchmark": is_real,
        "observed": {
            "requests_completed": num_requests,
            "batch_wall_seconds": round(wall_seconds, 3),
            "latency_p50_ms": percentile(latencies, 50),
            "latency_p95_ms": percentile(latencies, 95),
            "latency_mean_ms": round(statistics.mean(latencies), 3),
            "requests_per_second": round(num_requests / wall_seconds, 3),
            "total_output_tokens": tokens,
            "output_tokens_per_second": round(tokens / wall_seconds, 3) if is_real else None,
        },
        "caveat": (
            "DEMO MODE: no model was run. Do not cite this as LLM performance."
            if not is_real else
            "Client-observed latency includes HTTP and queueing; model weights, hardware, "
            "and workload must be held constant for backend comparisons."
        ),
    }


def main():
    parser = argparse.ArgumentParser(description="Benchmark an InferenceForge server")
    parser.add_argument("--url", default="http://127.0.0.1:8000")
    parser.add_argument("--prompt", default="Explain what LLM inference latency means.")
    parser.add_argument("--requests", type=int, default=10)
    parser.add_argument("--concurrency", type=int, default=2)
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--max-new-tokens", type=int, default=32)
    parser.add_argument("--output", type=Path, default=Path("results/latest.json"))
    args = parser.parse_args()
    report = asyncio.run(run_benchmark(
        args.url, args.prompt, args.requests, args.concurrency,
        args.warmups, args.max_new_tokens
    ))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"Report written to: {args.output}")


if __name__ == "__main__":
    main()
