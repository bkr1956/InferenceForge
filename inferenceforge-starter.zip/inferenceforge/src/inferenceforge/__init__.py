"""InferenceForge: LLM inference engineering, one measurable step at a time."""
__version__ = "0.1.0"
