import pytest
from inferenceforge.benchmark import percentile


def test_percentiles():
    assert percentile([1, 2, 3, 4, 5], 95) == 5
    assert percentile([1, 2, 3, 4, 5], 50) == 3
    with pytest.raises(ValueError):
        percentile([], 95)
