from fastapi.testclient import TestClient
from inferenceforge.api import app

client = TestClient(app)


def test_health():
    result = client.get("/health")
    assert result.status_code == 200
    assert result.json()["status"] == "ok"


def test_demo_is_explicitly_non_real():
    result = client.post("/v1/generate", json={"prompt": "Hello"})
    assert result.status_code == 200
    payload = result.json()
    assert payload["backend"] == "demo"
    assert payload["generated_tokens"] is None
    assert "[DEMO ONLY]" in payload["text"]
    assert payload["duration_ms"] >= 0


def test_prompt_validation():
    assert client.post("/v1/generate", json={"prompt": ""}).status_code == 422
    assert client.post("/v1/generate", json={"prompt": "a", "max_new_tokens": 0}).status_code == 422


def test_prometheus_endpoint():
    result = client.get("/metrics")
    assert result.status_code == 200
    assert "inferenceforge_generation_requests_total" in result.text
