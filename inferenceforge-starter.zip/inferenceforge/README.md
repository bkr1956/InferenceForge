# InferenceForge

**Reproducible LLM inference, benchmarking, and performance engineering.**

> Status: **Milestone 1 starter.** This is not yet a complete production serving platform.
> The default `demo` backend does **not** run an LLM. Its timings must **never** be
> represented as model inference benchmarks.

## Goal

Develop an evidence-driven LLM performance engineering portfolio project. Compare
serving methods using consistent prompts, model versions, hardware, and workload.
Document not only wins but regressions and limitations.

## Architecture

```mermaid
flowchart TD
    Client[Client / Benchmark CLI] --> API[FastAPI /v1/generate]
    API --> HF[Hugging Face local model]
    API --> DEMO[Demo backend for CI only]
    API --> MET[Prometheus /metrics]
    Future[Future: vLLM GPU serving] -.-> Client
    Future -.-> MET
```

## Requirements

- Python 3.11+ (3.11 or 3.12 recommended), Git, and internet for installing packages.
- CPU works for the small baseline model but may be slow. GPU is optional at first.
- On Windows, run these commands in **PowerShell** from the extracted project folder.

## Step 1: Start and test the project

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m pytest -q
uvicorn inferenceforge.api:app --reload
```

If PowerShell blocks activation, use `cmd.exe` with `.venv\Scripts\activate.bat`
or call `.venv\Scripts\python.exe -m pip ...` without activation.

Open `http://127.0.0.1:8000/docs` for API documentation. Run a demo benchmark
in **another PowerShell window** with the same venv activated:

```powershell
inferbench --requests 10 --concurrency 2 --output results/demo.json
```

The demo report sets `is_real_llm_benchmark: false` and token throughput to `null`.

## Step 2: Switch to real model inference

Install the optional model dependencies in the same environment:

```powershell
python -m pip install -e ".[model]"
$env:INFERENCEFORGE_BACKEND = "hf"
$env:INFERENCEFORGE_MODEL = "HuggingFaceTB/SmolLM2-135M-Instruct"
uvicorn inferenceforge.api:app --reload
```

The first request downloads the public Hugging Face model. The next command
must run in another terminal while the server is running:

```powershell
inferbench --requests 6 --concurrency 1 --max-new-tokens 16 --output results/real-baseline.json
```

The API loads the model lazily on the first generate request, so the benchmark
performs warmups before timing. The chosen 135M model is for a modest baseline,
not for production answer quality.

### Inspect endpoints

- `GET /health`: process health and configured backend
- `POST /v1/generate`: input `{ "prompt": "Hi", "max_new_tokens": 16 }`
- `GET /metrics`: Prometheus-compatible metrics
- `GET /docs`: interactive OpenAPI specification

## Benchmark interpretation

Benchmark JSON includes a UTC timestamp, environment, request and concurrency
settings, latency p50/p95, batch requests/sec and real-model output tokens/sec.
It is a **client-observed**, fixed-output-cap benchmark, not time-to-first-token.
Measurements must distinguish server queueing from actual model execution.

**Rules:** warm up the model; compare identical prompt, tokens, model revision,
quantization, accelerator and concurrency; record model and device information;
repeat experiments; report variance; never invent speedup percentages.

The first HF backend is deliberately single-threaded for model safety. More
concurrent HTTP clients do not automatically imply more parallel token generation.
Streaming, TTFT, continuous batching, GPU utilization and memory profiling will
be added in later milestones.

## Milestones

- [x] FastAPI service, explicit demo backend, local HF baseline, load-test CLI
- [x] p50/p95 request latency and requests/sec, JSON benchmark artifacts
- [x] Prometheus metrics, validation, unit tests, GitHub CI
- [ ] Real GPU profiling (`torch.profiler`), memory and per-token timings
- [ ] OpenAI-compatible streaming API and time-to-first-token
- [ ] vLLM backend and continuous batching benchmark
- [ ] Docker, Prometheus + Grafana dashboard, deployment
- [ ] Quality evaluation and performance-regression gates
- [ ] Optional JAX / XLA / Pallas experiments on appropriate hardware

## How to publish

```powershell
git init
git add .
git commit -m "feat: initial inference service and benchmark harness"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/inferenceforge.git
git push -u origin main
```

Create the blank public repository at github.com first; replace `YOUR_USERNAME`.
Do not upload downloaded model weights, secrets, generated artifacts or fake results.

## Licensing

MIT; model weights are governed by the individual model's separate license.
